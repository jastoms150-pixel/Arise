#!/usr/bin/env python3
"""
Generates Android launcher icons and splash screen for ARISE.
Run after `npx cap add android`.
"""
import os, math
from PIL import Image, ImageDraw

def make_icon(size):
    img = Image.new("RGBA", (size, size), "#050816")
    draw = ImageDraw.Draw(img)
    cx, cy = size // 2, size // 2

    # Outer glow ring
    for i in range(4, 0, -1):
        r = int(size * 0.46) + i * 2
        draw.ellipse([cx - r, cy - r, cx + r, cy + r],
                     outline=(244, 166, 41, 30 + i * 15), width=max(1, size // 64))

    # Gold circle border
    r = int(size * 0.46)
    draw.ellipse([cx - r, cy - r, cx + r, cy + r],
                 outline=(244, 166, 41, 220), width=max(2, size // 32))

    # "A" triangle (stylised)
    s = int(size * 0.28)
    tip_y = cy - s
    base_y = cy + int(s * 0.72)
    left_x = cx - int(s * 0.62)
    right_x = cx + int(s * 0.62)
    in_left  = cx - int(s * 0.20)
    in_right = cx + int(s * 0.20)
    in_y     = cy + int(s * 0.10)

    pts = [(cx, tip_y), (right_x, base_y), (in_right, in_y), (in_left, in_y), (left_x, base_y)]
    draw.polygon(pts, fill=(244, 166, 41))

    # Crossbar cutout
    bar_h = max(2, size // 28)
    bar_y = cy - int(s * 0.10)
    bar_l = cx - int(s * 0.44)
    bar_r = cx + int(s * 0.44)
    draw.rectangle([bar_l, bar_y - bar_h, bar_r, bar_y + bar_h], fill="#050816")

    # Small star dots
    dot_r = max(1, size // 48)
    for angle, dist in [(30, 0.38), (150, 0.38), (270, 0.42)]:
        rad = math.radians(angle)
        dx = int(math.cos(rad) * size * dist)
        dy = int(math.sin(rad) * size * dist)
        draw.ellipse([cx + dx - dot_r, cy + dy - dot_r,
                      cx + dx + dot_r, cy + dy + dot_r], fill=(244, 166, 41, 160))

    return img


def make_splash(w, h):
    img = Image.new("RGBA", (w, h), "#050816")
    draw = ImageDraw.Draw(img)
    cx, cy = w // 2, h // 2

    # Subtle radial glow
    for i in range(120, 0, -10):
        alpha = max(0, 18 - i // 8)
        r = int(min(w, h) * 0.35) + i
        draw.ellipse([cx - r, cy - r, cx + r, cy + r],
                     outline=(244, 166, 41, alpha), width=2)

    # Centre icon
    icon_size = int(min(w, h) * 0.28)
    icon = make_icon(icon_size)
    offset_x = cx - icon_size // 2
    offset_y = cy - icon_size // 2 - int(h * 0.04)
    img.paste(icon, (offset_x, offset_y), icon)

    return img


# ── Icon sizes ────────────────────────────────────────────────────────────
BASE = "android/app/src/main/res"
icons = [
    (f"{BASE}/mipmap-mdpi",    48),
    (f"{BASE}/mipmap-hdpi",    72),
    (f"{BASE}/mipmap-xhdpi",   96),
    (f"{BASE}/mipmap-xxhdpi",  144),
    (f"{BASE}/mipmap-xxxhdpi", 192),
]

for folder, size in icons:
    os.makedirs(folder, exist_ok=True)
    img = make_icon(size).convert("RGB")
    img.save(f"{folder}/ic_launcher.png")
    # Round icon (same image, Android clips it)
    img_full = make_icon(size)
    img_full.save(f"{folder}/ic_launcher_round.png")
    print(f"✓ Icon {size}x{size} → {folder}")

# ── Splash screen (2048x2048 covers all densities) ────────────────────────
splash_dir = f"{BASE}/drawable"
os.makedirs(splash_dir, exist_ok=True)
splash = make_splash(2048, 2048).convert("RGB")
splash.save(f"{splash_dir}/splash.png")
print("✓ Splash screen → android/app/src/main/res/drawable/splash.png")

print("\nAll icons and splash generated.")
