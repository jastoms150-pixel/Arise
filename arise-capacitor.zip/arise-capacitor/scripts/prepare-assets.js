const fs = require("fs");
const path = require("path");

const wwwDir = path.join(__dirname, "..", "www");
const jsDir = path.join(wwwDir, "js");
const cssDir = path.join(wwwDir, "css");
const fontsDir = path.join(wwwDir, "fonts");

[jsDir, cssDir, fontsDir].forEach(d => fs.mkdirSync(d, { recursive: true }));

// ── Copy React & ReactDOM UMD builds ──────────────────────────────────────
const reactSrc = path.join(__dirname, "..", "node_modules", "react", "umd", "react.production.min.js");
const reactDomSrc = path.join(__dirname, "..", "node_modules", "react-dom", "umd", "react-dom.production.min.js");
fs.copyFileSync(reactSrc, path.join(jsDir, "react.min.js"));
fs.copyFileSync(reactDomSrc, path.join(jsDir, "react-dom.min.js"));
console.log("✓ React & ReactDOM copied");

// ── Copy font files ───────────────────────────────────────────────────────
const fontMap = [
  { pkg: "cinzel-decorative", pattern: "cinzel-decorative-latin-700-normal.woff2", out: "cinzel-decorative-700.woff2" },
  { pkg: "cinzel",            pattern: "cinzel-latin-400-normal.woff2",             out: "cinzel-400.woff2" },
  { pkg: "cinzel",            pattern: "cinzel-latin-600-normal.woff2",             out: "cinzel-600.woff2" },
  { pkg: "nunito",            pattern: "nunito-latin-400-normal.woff2",             out: "nunito-400.woff2" },
  { pkg: "nunito",            pattern: "nunito-latin-600-normal.woff2",             out: "nunito-600.woff2" },
  { pkg: "nunito",            pattern: "nunito-latin-700-normal.woff2",             out: "nunito-700.woff2" },
];

fontMap.forEach(({ pkg, pattern, out }) => {
  const src = path.join(__dirname, "..", "node_modules", `@fontsource/${pkg}`, "files", pattern);
  if (fs.existsSync(src)) {
    fs.copyFileSync(src, path.join(fontsDir, out));
    console.log(`✓ Font: ${out}`);
  } else {
    // fallback: search files directory
    const filesDir = path.join(__dirname, "..", "node_modules", `@fontsource/${pkg}`, "files");
    if (fs.existsSync(filesDir)) {
      const all = fs.readdirSync(filesDir);
      const match = all.find(f => f.includes("latin") && f.includes("normal") && f.endsWith(".woff2") && f.includes(pattern.split("-")[pattern.split("-").length - 3]));
      if (match) {
        fs.copyFileSync(path.join(filesDir, match), path.join(fontsDir, out));
        console.log(`✓ Font (fallback match): ${out}`);
      } else {
        console.warn(`⚠ Font not found: ${pattern}`);
      }
    }
  }
});

// ── Write fonts.css ───────────────────────────────────────────────────────
const fontsCss = `
@font-face {
  font-family: 'Cinzel Decorative';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('../fonts/cinzel-decorative-700.woff2') format('woff2');
}
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url('../fonts/cinzel-400.woff2') format('woff2');
}
@font-face {
  font-family: 'Cinzel';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url('../fonts/cinzel-600.woff2') format('woff2');
}
@font-face {
  font-family: 'Nunito';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url('../fonts/nunito-400.woff2') format('woff2');
}
@font-face {
  font-family: 'Nunito';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url('../fonts/nunito-600.woff2') format('woff2');
}
@font-face {
  font-family: 'Nunito';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url('../fonts/nunito-700.woff2') format('woff2');
}
`.trim();

fs.writeFileSync(path.join(cssDir, "fonts.css"), fontsCss);
console.log("✓ fonts.css written");
console.log("\nAll assets prepared successfully.");
