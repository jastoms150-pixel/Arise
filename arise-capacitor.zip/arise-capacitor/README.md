# ARISE – African Journeys
**GameUp Africa** | Educational mobile game

---

## What this is
A fully offline Android app that teaches African history through interactive
stories and quizzes. 6 leaders, 18 facts, 6 challenges. Progress is saved on device.

---

## How to build the APK (phone-only, no PC needed)

### Step 1 — Create GitHub repo
1. Go to github.com and sign in
2. Click **New repository**
3. Name it `arise-app`, set it to **Public**, click **Create**

### Step 2 — Upload these files
Upload all files maintaining this exact structure:
```
arise-app/
├── www/
│   └── index.html
├── scripts/
│   ├── prepare-assets.js
│   └── generate-icons.py
├── .github/
│   └── workflows/
│       └── build-apk.yml
├── capacitor.config.json
├── package.json
├── .gitignore
└── README.md
```

### Step 3 — Watch it build
1. Go to your repo → **Actions** tab
2. You will see "Build ARISE APK" running automatically
3. Wait ~5–8 minutes for it to complete

### Step 4 — Download your APK
1. Click the completed workflow run
2. Scroll down to **Artifacts**
3. Download **ARISE-APK**
4. Unzip → find `ARISE-v1.0.apk`
5. Share it or install directly

---

## Installing the APK
1. Transfer to Android phone
2. Tap the file
3. If prompted: Settings → Allow from this source → Install
4. ARISE appears on your home screen

---

## App features
- Fully offline after install (no internet needed)
- Progress saved (XP + unlocked leaders persist)
- No browser bar, no URL, no install prompts
- Dark gold theme, animated Africa map
- 6 leaders unlocked sequentially: Mansa Musa → Amina → Jaja → Nefertiti → Yaa Asantewaa → Shaka

---

## Adding more leaders
Edit `www/index.html` and add entries to the `LEADERS` array.
Each leader needs: `id`, `name`, `title`, `years`, `region`, `mx`/`my` (map position),
`color`, `dim`, `bg`, `symbol`, `facts` (3 objects), and `quiz`.

---

*Built with Capacitor.js + React + GitHub Actions*
*GameUp Africa — Reclaiming the stories that belong to all of us.*
